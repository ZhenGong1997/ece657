# ECE657 A1
The model has already been pre-trained by running train.py.

To run and evaluate the model, TA can either modify the runme.py file to change the test dataset or creating a new file. Re-train the model is unnecessary, but you can try to run train.py to verify the algorithm as it prints out training error and training accuracy for reference.